import { Component, Inject } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
    selector: 'search-customer-info',
    templateUrl: 'app/SearchCustomer.component.html'
    //styleUrls: ['app/mSearchCustomer.css']
})
export class searchcustomercomponent {
}